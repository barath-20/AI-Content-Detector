import React from 'react'

const Home = () => {
  return (
    <div>
        <h2>Hello this is home components</h2>
    </div>
  )
}

export default Home